package com.cs.CalculatorService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
