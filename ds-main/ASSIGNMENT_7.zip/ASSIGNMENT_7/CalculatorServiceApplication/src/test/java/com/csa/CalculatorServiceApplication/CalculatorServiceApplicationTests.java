package com.csa.CalculatorServiceApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
